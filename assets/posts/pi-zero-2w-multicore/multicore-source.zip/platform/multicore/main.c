#include "uart.h"

/* Use .bss rather than our small boot stack for input. */
static char input[256];

unsigned long read_core_alive(unsigned long core);


static unsigned long timer_ticks(void){
    unsigned long ticks;


    __asm__ volatile(
        "isb\n"
        "mrs %0, cntpct_el0" //read counter timer register
        : "=r"(ticks)
        :
        : "memory"
    );
    return ticks;

}

static unsigned long timer_frequency(void)
{

    unsigned long frequency;


    __asm__ volatile(

        "mrs %0, cntfrq_el0"
        : "=r"(frequency)
    );
    return frequency;
}


static int strings_equal(const char *a, const char *b)
{
    while (*a && *a == *b) {
        a++;
        b++;
    }

    return *a == *b;
}

void write_core_counter(unsigned long core, unsigned long value);
unsigned long read_core_counter(unsigned long core);
//simple continuous function where each core will count by a different increment
static void counter_worker(unsigned long core, unsigned long step)
{
    volatile unsigned long counter = 0;
    for (;;){
        counter += step;
        write_core_counter(core, counter);
    }
}

void kernel_main(void)
{
    uart_init();
    //now we need to add in the core reads
    unsigned long timeout = timer_frequency(); //one seconds worth
    unsigned long start = timer_ticks(); //get our starting time

    unsigned long core1_alive = 0;
    unsigned long core2_alive = 0;
    unsigned long core3_alive = 0;

    while(!(core1_alive && core2_alive && core3_alive) && ((timer_ticks()-start) < timeout)){
        core1_alive = read_core_alive(1);
        core2_alive = read_core_alive(2);
        core3_alive = read_core_alive(3);
    }

    unsigned long elapsed_ticks = timer_ticks() - start; //how long that took in ticks
    unsigned long elapsed_ms = (elapsed_ticks * 1000UL) / timeout; //convert to real milliseconds

    uart_puts(core1_alive ? "Core 1: alive\r\n" : "Core 1: startup timed out\r\n");
    uart_puts(core2_alive ? "Core 2: alive\r\n" : "Core 2: startup timed out\r\n");
    uart_puts(core3_alive ? "Core 3: alive\r\n" : "Core 3: startup timed out\r\n");
    uart_puts("Worker startup wait time: ");
    uart_put_ulong(elapsed_ms);
    uart_puts(" ms\r\n");

    uart_puts("terminal ready\r\n");

    while (1) {
        uart_puts("Pi> ");
        uart_readline(input, sizeof(input));
        if (strings_equal(input, "core-counters"))
        {
            uart_puts("Core 1 counter: ");
            uart_put_ulong(read_core_counter(1));
            uart_puts("\r\n");

            uart_puts("Core 2 counter: ");
            uart_put_ulong(read_core_counter(2));
            uart_puts("\r\n");

            uart_puts("Core 3 counter: ");
            uart_put_ulong(read_core_counter(3));
            uart_puts("\r\n");

        }
        uart_puts("Received: ");
        uart_puts(input);
        uart_puts("\r\n");
    }
}


void secondary_main(unsigned long core)
{

switch (core){
    case 1:
        counter_worker(1, 1);
        break;

    case 2:
        counter_worker(2, 2);
        break;

    case 3:
        counter_worker(3, 3);
        break;
}
    for (;;){
        __asm__ volatile("wfe");
    }

}
