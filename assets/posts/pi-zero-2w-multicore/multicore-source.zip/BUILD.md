# Multicore counter experiment

Source commit: 7e127b6de840532186276aae94cc98a283d2e96b

Run in WSL/Linux from this extracted directory. Install clang, lld, llvm and make if needed.

```sh
mkdir -p build/multicore
clang --target=aarch64-none-elf -c platform/multicore/boot.S -o build/multicore/boot.o
clang --target=aarch64-none-elf -std=c11 -ffreestanding -fno-builtin -fno-stack-protector -fno-unwind-tables -fno-asynchronous-unwind-tables -fno-pic -O0 -Wall -Wextra -Iplatform/multicore -c platform/multicore/main.c -o build/multicore/main.o
clang --target=aarch64-none-elf -std=c11 -ffreestanding -fno-builtin -fno-stack-protector -fno-unwind-tables -fno-asynchronous-unwind-tables -fno-pic -O0 -Wall -Wextra -Iplatform/multicore -c platform/multicore/uart.c -o build/multicore/uart.o
ld.lld -m aarch64elf -T platform/multicore/linker.ld -Map=build/multicore/kernel8.map -o build/multicore/kernel8.elf build/multicore/boot.o build/multicore/main.o build/multicore/uart.o
llvm-objcopy -O binary build/multicore/kernel8.elf build/multicore/kernel8.img
```

Copy build/multicore/kernel8.img to the boot partition of a prepared Pi Zero 2 W card. Merge config.txt.example settings into its config.txt. Use 3.3 V UART logic: adapter GND to physical pin6, RXD to pin8, TXD to pin10; adapter VCC disconnected. Components up, microSD left/camera right/header top: these are outer-row columns3,4,5 from the left. UART115200 8N1, no flow control. Type core-counters. This is a bounded educational experiment, not hard-real-time or safety validation.
