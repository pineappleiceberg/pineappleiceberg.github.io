#ifndef PI_ZERO2_UART_H
#define PI_ZERO2_UART_H

#include <stddef.h>

void uart_init(void);
void uart_putc(char c);
char uart_getc(void);
void uart_puts(const char *str);
void uart_put_ulong(unsigned long value);
size_t uart_readline(char *buffer, size_t capacity);

#endif /* PI_ZERO2_UART_H */
