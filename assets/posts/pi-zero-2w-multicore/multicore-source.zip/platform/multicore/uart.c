
#include <stdint.h>
#include "uart.h"

#define AUX_BASE 0x3F215000UL
#define AUX_MU_LCR  (AUX_BASE + 0x4CUL) //8-bit char's
#define AUX_MU_BAUD (AUX_BASE + 0x68UL) // 115200 baud rate
#define AUX_ENABLES (AUX_BASE + 0X04UL) //enable mini uart
#define AUX_MU_CNTL (AUX_BASE +0X60UL) //lever for tx and rx
#define AUX_MU_IER (AUX_BASE + 0x44UL) //interrupt enable
#define AUX_MU_IIR (AUX_BASE + 0x48UL) //FIFO control
#define AUX_MU_MCR (AUX_BASE + 0x50UL) //modem control
#define AUX_MU_IO  (AUX_BASE + 0x40UL) // data register, sents to tx FIFO
#define AUX_MU_LSR (AUX_BASE + 0x54UL) //line status register



#define GPIO_BASE 0x3F200000UL
#define GPFSEL1    (GPIO_BASE + 0x04UL)
#define GPPUD     (GPIO_BASE + 0x94UL)
#define GPPUDCLK0 (GPIO_BASE + 0x98UL)



static uint32_t mmio_read32(uintptr_t address){
	return *(volatile uint32_t *)address;
}

static void mmio_write32(uintptr_t address, uint32_t value){

	*(volatile uint32_t *)address = value;

}


void gpio_uart_pins(void){
	uint32_t selector = mmio_read32(GPFSEL1);

	selector &= ~((7U << 12) | (7U << 15));

	selector |= (2u << 12) | (2u << 15);

	mmio_write32(GPFSEL1, selector);
}

void mini_uart_enable(void){
	uint32_t value = mmio_read32(AUX_ENABLES);
	value |= (1u << 0);
	mmio_write32(AUX_ENABLES, value);

	mmio_write32(AUX_MU_CNTL,0U);


}

void mini_uart_configure(void)
{
    mmio_write32(AUX_MU_LCR, 3u); //write the 8-bit mode
    mmio_write32(AUX_MU_BAUD, 270u); //set the baud to 115200 @ 250mhz
	//we're gonna poll instead of using interrupts
	mmio_write32(AUX_MU_IER, 0u); //no uart interrupts
	mmio_write32(AUX_MU_MCR, 0u); //no modem
	mmio_write32(AUX_MU_IIR, 6u); //clear all the rx tx FIFO's

}


static void delay_cycles(void)
{
    for (volatile unsigned i = 0; i < 200; i++) {
        __asm__ volatile("nop");
    }
}


void gpio_uart_disable_pulls(void)
{
    mmio_write32(GPPUD, 0u); //disable pull-up and pull-down resistors
    delay_cycles(); //add our 200 nops

    mmio_write32(GPPUDCLK0, (1u << 14) | (1u << 15)); //configure GPIO 14 and 15
    delay_cycles();

    mmio_write32(GPPUD, 0u); //Clear control reg
    mmio_write32(GPPUDCLK0, 0u); //clear clock reg
}

void uart_putc(char c)
{
    while ((mmio_read32(AUX_MU_LSR) & (1u << 5)) == 0u) {
    } //just continuously polling until its ready
    mmio_write32(AUX_MU_IO, (uint8_t)c); //send the character, cast to 8 bit uint
}

void uart_put_ulong(unsigned long value)
{
    char digits[20];
    size_t count = 0;

    do {
        digits[count++] = (char)('0' + (value % 10));
        value /= 10;
    } while (value != 0);

    while (count > 0) {
        uart_putc(digits[--count]);
    }
}

char uart_getc(void)
{
    while ((mmio_read32(AUX_MU_LSR) & (1u << 0)) == 0u) { //polling
    }
    return (char)(mmio_read32(AUX_MU_IO) & 0xFFu);
}

//this is effectively our printf alternative
void uart_puts(const char *str)
{
    while (*str != '\0') {
        uart_putc(*str);
        str++;
    }
}


//now we need an initalization function

void uart_init(void){

    mini_uart_enable();
    mini_uart_configure();
    gpio_uart_disable_pulls();
    gpio_uart_pins();
    mmio_write32(AUX_MU_CNTL, 3u); //enable tx and rx
}

//basically need an interactive terminal
size_t uart_readline(char *buffer, size_t capacity)
{
    if (buffer == NULL || capacity == 0) {
        return 0;
    }

    size_t length = 0;

    while (1) {
        char c = uart_getc();
        if (c == '\r' || c == '\n') {
            buffer[length] = '\0';
            uart_puts("\r\n");
            return length;
        }
        if (c == '\b' || c == 127) {
            if (length > 0) {
                length--;
                uart_puts("\b \b");
            }
            continue;
        }
        if ((unsigned char)c < 32) {
            continue;
        }
        if (length < capacity - 1) {
            buffer[length++] = c;
            uart_putc(c);
        }
        else {
            uart_putc('\a'); //buffer is too full
        }
    }
}
